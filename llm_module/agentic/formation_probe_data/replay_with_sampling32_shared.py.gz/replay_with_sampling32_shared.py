"""Small correctly formatted chat checks, separate from scored task policy."""
import json,sys,time,urllib.request,hashlib
from pathlib import Path
r=Path(__file__).parent;mode=sys.argv[1];out=r/('qualitative-'+mode+'.json')
if out.exists():raise RuntimeError('Preserve prior qualitative evidence')
prompts=json.loads((r/'qualitative-prompts.json').read_text());rows=[]
for p in prompts:
 payload=dict(model='google/gemma-4-31B-it',messages=p['messages'],max_tokens=2048,temperature=0,top_p=.95,top_k=20,seed=9472,cache_salt='qual-'+p['id'],return_token_ids=True)
 req=urllib.request.Request('http://localhost:8000/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'});t=time.time()
 with urllib.request.urlopen(req,timeout=600) as response:d=json.loads(response.read())
 choice=d['choices'][0];content=choice['message'].get('content') or '';ok=content.strip()==p.get('expected_text') if 'expected_text' in p else False
 if 'expected_json' in p:
  try:ok=json.loads(content)==p['expected_json']
  except Exception:ok=False
 rows.append(dict(id=p['id'],start=t,end=time.time(),payload=payload,response=d,expected_content_match=ok,natural_stop=choice['finish_reason']=='stop'));out.write_text(json.dumps(rows,indent=2));print(json.dumps({'id':p['id'],'content':content,'expected_content_match':ok,'finish_reason':choice['finish_reason']}),flush=True)

assert all(row['expected_content_match'] and row['natural_stop'] for row in rows), 'Qualitative check failed'

"""Heterogeneous sampled request rows, with concurrent cache-hit continuations."""
import concurrent.futures,hashlib,json,sys,threading,time,urllib.request
from pathlib import Path
R=Path(__file__).parent;tag=sys.argv[1];target=R/(tag+'-concurrent-sampling.json');assert not target.exists()
ids=json.loads((R/'token_ids.json').read_text())*8
results=[]
def sampled_req(i,n,salt,output,barrier=None):
 tokens=list(ids[:n]);tokens[0]=14000+i
 body=dict(model='google/gemma-4-31B-it',prompt=tokens,max_tokens=output,ignore_eos=True,temperature=(0,.3,1.)[i%3],top_p=(1.,.8,.95)[i%3],top_k=(1,10,20)[i%3],seed=9472+i,cache_salt=salt,return_token_ids=True)
 if barrier is not None:barrier.wait(timeout=30)
 start=time.time()
 request=urllib.request.Request('http://127.0.0.1:8000/v1/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=1200) as response:data=json.loads(response.read())
 assert data['usage']['completion_tokens']==output
 return dict(row=i,n=n,body_sha256=hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest(),sampling={k:body[k] for k in ('temperature','top_p','top_k','seed')},start=start,end=time.time(),response=data)
for wave in range(3):
 # Prime in identical fixed order, then release all continuation callers together.
 prime=[sampled_req(i,2048,f'concurrent-sampling-{wave}-{i}',2) for i in range(16)]
 barrier=threading.Barrier(16);started=time.time()
 with concurrent.futures.ThreadPoolExecutor(16) as pool:
  data=list(pool.map(lambda i:sampled_req(i,2048+257+16*(i%16),f'concurrent-sampling-{wave}-{i}',32,barrier),range(16)))
 results.append(dict(wave=wave,prime=prime,data=data,wall_s=time.time()-started));target.write_text(json.dumps(results,indent=2));print('CONCURRENT_SAMPLING',wave,results[-1]['wall_s'],flush=True)

"""Fixed archived SWE queries; generated replies do not change subsequent queries."""
import concurrent.futures,hashlib,json,statistics,sys,time,urllib.request
from pathlib import Path
R=Path(__file__).parent;tag=sys.argv[1];records=json.loads((R/'reconstructed-swe512.json').read_text())['records'];out=R/(tag+'-replay.json');assert not out.exists()
ACTORS=32
base='http://127.0.0.1:8000';results=[]
expected_tokens={(x['actor'],x['turn']):x['token_ids_sha256'] for x in json.loads((R/'reconstruction-engine-tokenization512.json').read_text())}
def call(path,body):
 return urllib.request.urlopen(urllib.request.Request(base+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=1200)
# Host-only tokenization verifies the reconstruction before timed device work.
verified=[]
for row in records:
 body=json.loads(json.dumps({k:v for k,v in row['body'].items() if k in ('model','messages','tools','tool_choice')}))
 # ChatCompletionRequest normalizes this legacy field; TokenizeChatRequest does not.
 for message in body['messages']:
  legacy=message.pop('reasoning_content',None)
  if legacy is not None and message.get('reasoning') is None:message['reasoning']=legacy
 body['add_generation_prompt']=True
 with call('/tokenize',body) as response:d=json.loads(response.read())
 token_hash=hashlib.sha256(json.dumps(d['tokens'],separators=(',',':')).encode()).hexdigest()
 assert token_hash==expected_tokens[(row['actor'],row['turn'])],(row['actor'],row['turn'],'token-array mismatch')
 verified.append(dict(token_ids_sha256=token_hash,actor=row['actor'],turn=row['turn'],original=row['original_prompt_tokens'],reconstructed=d['count'],exact=d['count']==row['original_prompt_tokens']))
(R/(tag+'-reconstruction-check.json')).write_text(json.dumps(verified,indent=2))
assert all(x['exact'] for x in verified), 'Prompt counts differ: reconstructed workload requires diagnosis'
def req(row,n):
 body=dict(row['body']);body.update(max_tokens=min(row['original_completion_tokens'],128),ignore_eos=True,seed=9472,cache_salt=f'replay-{n}-{row["actor"]}',stream=True,stream_options={'include_usage':True})
 started=time.time();first=None;chunks=[];usage=None;response_id=None
 with call('/v1/chat/completions',body) as response:
  for raw in response:
   if not raw.startswith(b'data:'):continue
   payload=raw[5:].strip()
   if payload==b'[DONE]':break
   data=json.loads(payload)
   if data.get('id'):response_id=data['id']
   if data.get('usage'):usage=data['usage']
   for choice in data.get('choices',[]):
    delta=choice.get('delta',{})
    if any(delta.get(k) for k in ('content','reasoning_content','reasoning','tool_calls')):
     if first is None:first=time.time()
     chunks.append(delta)
 ended=time.time();assert usage is not None
 assert usage['completion_tokens']==body['max_tokens'],usage
 assert usage['prompt_tokens']==row['original_prompt_tokens'],usage
 return dict(actor=row['actor'],turn=row['turn'],source_response_id=row['response_id'],response_id=response_id,request_sha256=hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest(),start=started,end=ended,ttft_s=None if first is None else first-started,latency_s=ended-started,usage=usage,deltas=chunks)
def actor(i,n):
 rows=[r for r in records if r['actor']==i and r['turn']<n//ACTORS];data=[]
 for row in rows:
  data.append(req(row,n))
  if row is not rows[-1]:time.sleep((0,.25,1.,2.)[(i+row['turn'])%4])
 return data
for n in (128,256,512):
 started=time.time()
 with concurrent.futures.ThreadPoolExecutor(ACTORS) as pool:data=[x for rows in pool.map(lambda i:actor(i,n),range(ACTORS)) for x in rows]
 elapsed=time.time()-started
 item=dict(n=n,actors=ACTORS,client_workers=32,makespan_s=elapsed,requests_per_second=n/elapsed,prompt_tokens=sum(x['usage']['prompt_tokens'] for x in data),completion_tokens=sum(x['usage']['completion_tokens'] for x in data),ttft_median_s=statistics.median(x['ttft_s'] for x in data if x['ttft_s'] is not None),latency_p95_s=sorted(x['latency_s'] for x in data)[int(.95*(n-1))],records=data)
 results.append(item);out.write_text(json.dumps({'scope':'Fixed real SWE conversation replay, prompt-count verified, output capped128 tokens with original sampling profile+fixed seed; not scored agent evaluation. 32 active client workers, C16 server with max_num_seqs=16, closed loop with prescribed tool waits; generated replies not fed back.','waves':results},indent=2));print('REPLAY_WAVE',n,elapsed,flush=True)

# Shared skill suite follows timed replay, so it cannot warm the measured waves.
import json,sys,time,urllib.request
from pathlib import Path
shared_prompts = ['Write a haiku about machine learning.', 'Explain the difference between supervised and unsupervised learning in simple terms.', 'Complete this story: Once upon a time, in a faraway kingdom, there lived a curious young inventor who discovered', 'What are the three laws of thermodynamics?', 'Translate the following to French: "Hello, how are you today?"', 'Write a Python function to calculate the Fibonacci sequence.']
shared_metadata = {'model': 'google/gemma-4-31B-it', 'runtime_revision': 'main', 'local_checkpoint_revision': '842da3794eaa0b77d5f08bae87a17459d91ff475', 'observed_serving_cache_revision': '842da3794eaa0b77d5f08bae87a17459d91ff475', 'revision_scope': 'Local download metadata and both mounted HF cache refs/files agree before launch; actual prompt token arrays are saved by the serving endpoint.', 'local_checkpoint': '/home/mvasiljev/build/gemma-local-probe-model-842da379', 'tokenizer_class': 'GemmaTokenizer', 'tokenizer_module': 'transformers.models.gemma.tokenization_gemma', 'tokenizer_is_fast': True, 'tokenizer_class_proof': 'AutoTokenizer loaded local checkpoint in pinned runtime image, no network or devices', 'chat_template_present': True, 'prompt_mode': 'chat', 'endpoint': '/v1/chat/completions', 'prompt_source': '/home/mvasiljev/.codex/plugins/cache/tenstorrent-skills/tt-model-bringup/0.1.20/runtime/readiness_check/vllm_prompts.txt', 'prompt_source_sha256': '2ad452c15d8442d3fe641eb968bbd84e3bfe9acb01ddc540f451983c0da3cbbd', 'control': 'pristine validated-final-history source; no new HF run', 'files_sha256': {'config.json': 'e967dd38bc5cfd38bd09a995a7bf4a754075df2b46aba68f7fbb5a791e6d8dd1', 'tokenizer_config.json': '9f4fec4b1dc6ecddf8f4a92e9caea5971c0e67d81309f3f9066a2bee8c362633', 'chat_template.jinja': 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4'}}
shared_rows=[]
shared_out=Path(__file__).parent/(sys.argv[1]+'-shared-qualitative.json')
assert not shared_out.exists()
for shared_i,shared_prompt in enumerate(shared_prompts):
 shared_body=dict(model='google/gemma-4-31B-it',messages=[dict(role='user',content=shared_prompt)],max_tokens=2048,temperature=0,top_p=.95,top_k=20,seed=9472,cache_salt=f'shared-qualitative-{shared_i}',return_token_ids=True)
 shared_token_body=dict(model=shared_body['model'],messages=shared_body['messages'],add_generation_prompt=True)
 def shared_call(path,body):
  request=urllib.request.Request('http://127.0.0.1:8000'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(request,timeout=1200) as response:return json.loads(response.read())
 shared_tokenized=shared_call('/tokenize',shared_token_body)
 shared_started=time.time();shared_response=shared_call('/v1/chat/completions',shared_body)
 shared_rows.append(dict(id=shared_i,prompt=shared_prompt,payload=shared_body,tokenization=shared_tokenized,response=shared_response,start=shared_started,end=time.time()))
 shared_out.write_text(json.dumps(dict(metadata=shared_metadata,rows=shared_rows,verdict='Pending human review against pristine control'),indent=2))
 print('SHARED_QUALITATIVE',shared_i,shared_response['choices'][0]['finish_reason'],flush=True)
