"""Prespecified long-request seeds1..12, restored13440prefix, sequential B1 targets."""
import concurrent.futures,hashlib,json,os,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
source=json.loads((root/'quality-repetition-requests.json').read_text());oracle={x['response_id']:x for x in json.loads((root/'quality-repetition-renderer.json').read_text())};records=source['records'];assert len(records)==len(oracle)==2
endpoint=os.environ['GEMMA_PROBE_ENDPOINT'].rstrip('/');headers={'Content-Type':'application/json'}
if os.environ.get('GEMMA_PROBE_AUTH_TOKEN'):headers['Authorization']='Bearer '+os.environ['GEMMA_PROBE_AUTH_TOKEN']
def call(route,body):
 raw=json.dumps(body).encode();request=urllib.request.Request(endpoint+route,data=raw,headers=headers)
 with urllib.request.urlopen(request,timeout=3600) as response:return json.loads(response.read())
def persist(name,value):
 p=root/name;temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(p)
tokenize_bodies=json.loads((root/'quality-tokenization-requests-r3.json').read_text());assert set(tokenize_bodies)=={x['response_id'] for x in records}
tokens={}
for row in records:
 body=row['body'];assert {k:body[k] for k in ['model','max_tokens','temperature','top_p','top_k']}==dict(model='google/gemma-4-31B-it',max_tokens=8192,temperature=1.,top_p=.95,top_k=20)
 assert hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()==row['body_sha256']
 tokenized=call('/tokenize',tokenize_bodies[row['response_id']]);tokens[row['response_id']]=tokenized;persist('tokenization.json',tokens);ids=tokenized['tokens'];assert len(ids)==row['original_prompt_tokens']==oracle[row['response_id']]['original'];assert hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()==oracle[row['response_id']]['token_ids_sha256'];tokens[row['response_id']]=tokenized
persist('tokenization.json',tokens)
plan=json.loads((root/'quality-long-seed-plan-r4.json').read_text());assert plan['seeds']==list(range(1,13)) and plan['conditions']==['restored-prefix'] and plan['requests']==plan['warmups']==12
results=[];warms=[]
def execute(row,condition,seed):
 rid=row['response_id'];salt=f'quality-fixed-{condition}-{seed}-{rid}';body=dict(row['body'],seed=seed,cache_salt=salt,return_token_ids=True)
 begin=time.time();response=call('/v1/chat/completions',body);end=time.time();persist('raw-response-'+hashlib.sha256(f'{rid}/{condition}/{seed}'.encode()).hexdigest()+'.json',dict(response_id=rid,condition=condition,seed=seed,body_sha256=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest(),start=begin,end=end,response=response));choices=response['choices'];assert len(choices)==1;choice=choices[0];ids=choice.get('token_ids');assert isinstance(ids,list) and ids and all(type(x) is int for x in ids)
 usage=response['usage'];assert usage['prompt_tokens']==row['original_prompt_tokens'] and usage['completion_tokens']==len(ids) and len(ids)<=8192;assert choice['finish_reason'] in ('stop','length','tool_calls')
 cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens');expected=13440 if condition=='restored-prefix' and row['original_prompt_tokens']==13711 else 0
 if cached is not None:assert cached==expected,(rid,condition,cached,expected)
 return dict(response_id=rid,condition=condition,seed=seed,cache_salt=salt,expected_cached_tokens=expected,api_cached_tokens=cached,body_sha256=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest(),start=begin,end=end,response=response)
row=next(x for x in records if x['response_id']==plan['response_id']);assert row['original_prompt_tokens']==13711
condition='restored-prefix'
for seed in plan['seeds']:
 rid=row['response_id'];salt=f'quality-fixed-{condition}-{seed}-{rid}'
 body=dict(model=row['body']['model'],prompt=tokens[rid]['tokens'][:13441],max_tokens=1,temperature=0,seed=seed,cache_salt=salt,return_token_ids=True)
 begin=time.time();response=call('/v1/completions',body);end=time.time()
 warm=dict(condition=condition,seed=seed,cache_salt=salt,start=begin,end=end,response=response)
 persist(f'raw-warmup-{seed}.json',warm)
 assert response['usage']['prompt_tokens']==13441 and response['usage']['completion_tokens']==1
 choices=response['choices'];assert len(choices)==1 and choices[0]['finish_reason'] in ('stop','length')
 ids=choices[0]['token_ids'];assert len(ids)==1 and type(ids[0])is int
 cached=(response['usage'].get('prompt_tokens_details') or {}).get('cached_tokens');assert cached is None or cached==0
 warms.append(warm);persist('warmups.json',warms)
 results.append(execute(row,condition,seed))
 persist('results.json',dict(scope=plan['scope'],rows=results));print('QUALITY_LONG_SEED',seed,len(results[-1]['response']['choices'][0]['token_ids']),flush=True)
assert len(results)==len(warms)==12
persist('client-complete.json',dict(requests=12,warmups=12,plan_sha256=hashlib.sha256((root/'quality-long-seed-plan-r4.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((root/'quality-repetition-requests.json').read_bytes()).hexdigest(),renderer_sha256=hashlib.sha256((root/'quality-repetition-renderer.json').read_bytes()).hexdigest()))
