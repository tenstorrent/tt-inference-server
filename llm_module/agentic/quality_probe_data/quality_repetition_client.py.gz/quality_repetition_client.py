"""Six prespecified semantic continuations; changed prefix/RNG history is explicit."""
import hashlib,json,os,time,urllib.request
from pathlib import Path

root=Path(__file__).resolve().parent
payload_bytes=(root/'quality-long-continuation-r5.json').read_bytes()
payload=json.loads(payload_bytes)
assert payload['seeds']==[0,9472,2026] and payload['cached_tokens']==13440
assert payload['generation_eos_ids']==[1,106,50]
assert [(c['label'],c['total_prompt_tokens'],c['remaining_original_cap']) for c in payload['cases']]==[('before-comment',14405,7498),('before-repeat',14421,7482)]
endpoint=os.environ['GEMMA_PROBE_ENDPOINT'].rstrip('/')
headers={'Content-Type':'application/json'}
if os.environ.get('GEMMA_PROBE_AUTH_TOKEN'):headers['Authorization']='Bearer '+os.environ['GEMMA_PROBE_AUTH_TOKEN']
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def persist(name,value):
 p=root/name;tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def call(body):
 raw=json.dumps(body).encode();assert json.loads(raw)==body
 req=urllib.request.Request(endpoint+'/v1/completions',data=raw,headers=headers)
 with urllib.request.urlopen(req,timeout=3600) as response:return json.loads(response.read())
def check(response,prompt,cached,maximum):
 choices=response['choices'];assert len(choices)==1
 choice=choices[0];ids=choice['token_ids']
 assert isinstance(ids,list) and 0<len(ids)<=maximum and all(type(x)is int and x>=0 for x in ids)
 assert choice['finish_reason'] in ('stop','length')
 if choice['finish_reason']=='length':assert len(ids)==maximum
 assert response['usage']['prompt_tokens']==prompt and response['usage']['completion_tokens']==len(ids)
 observed=(response['usage'].get('prompt_tokens_details') or {}).get('cached_tokens')
 assert observed is None or type(observed)is int and observed==cached
 return observed
original=payload['original_prompt_token_ids']
assert len(original)==13711 and hashlib.sha256(json.dumps(original,separators=(',',':')).encode()).hexdigest()=='178d17b9a3c3071b323dc44b1a81cf78b9e4ed7d8cd62e968ca59d3f49c132b1'
rows=[];warms=[]
for case in payload['cases']:
 ids=case['prompt_token_ids'];assert ids[:13711]==original and len(ids)==case['total_prompt_tokens']
 assert hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()==case['prompt_token_ids_sha256']
 assert case['reconstructed_prefix_tokens']+case['remaining_original_cap']==8192
 for seed in payload['seeds']:
  salt=f"quality-semantic-r5-{case['label']}-{seed}"
  common=dict(model='google/gemma-4-31B-it',seed=seed,cache_salt=salt,return_token_ids=True,stop_token_ids=payload['generation_eos_ids'])
  warm_body=dict(common,prompt=original[:13441],max_tokens=1,temperature=0)
  start=time.time();response=call(warm_body);end=time.time()
  warm=dict(kind='warmup',label=case['label'],seed=seed,cache_salt=salt,body=warm_body,body_sha256=digest(warm_body),start=start,end=end,response=response)
  persist(f"raw-warmup-{case['label']}-{seed}.json",warm)
  check(response,13441,0,1);warms.append(warm);persist('warmups.json',warms)
  body=dict(common,prompt=ids,max_tokens=case['remaining_original_cap'],temperature=1.,top_p=.95,top_k=20,skip_special_tokens=False)
  start=time.time();response=call(body);end=time.time()
  row=dict(kind='target',label=case['label'],seed=seed,cache_salt=salt,body=body,body_sha256=digest(body),start=start,end=end,response=response)
  persist(f"raw-response-{case['label']}-{seed}.json",row)
  check(response,case['total_prompt_tokens'],13440,case['remaining_original_cap'])
  rows.append(row);persist('results.json',dict(scope=payload['scope'],rows=rows))
  print('SEMANTIC_CONTINUATION',case['label'],seed,len(response['choices'][0]['token_ids']),flush=True)
assert len(rows)==len(warms)==6
persist('client-complete.json',dict(requests=6,warmups=6,payload_sha256=hashlib.sha256(payload_bytes).hexdigest(),client_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Execution only; reconstructed semantic prefix changes prefill/RNG history, not exact original-token replay.'))
