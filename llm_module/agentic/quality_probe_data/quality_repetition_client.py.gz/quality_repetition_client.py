"""One fixed busy-entry diagnostic; auxiliary forced lengths are not quality evidence."""
import concurrent.futures,hashlib,json,os,threading,time,traceback,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def valid_ids(ids):return isinstance(ids,list) and all(type(x)is int and x>=0 for x in ids)
def persist(name,value):
 p=root/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(p)
def main():
 protocol=json.loads((root/'quality-busy-protocol-r6.json').read_text())
 for name,expected in protocol['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
 records={r['response_id']:r for r in json.loads((root/'quality-busy-requests-r6.json').read_text())['records']}
 oracle={x['response_id']:x for x in json.loads((root/'quality-busy-tokenization-r6-proof.json').read_text())['rows']}
 payloads=json.loads((root/'quality-busy-tokenize-payload-r6.json').read_text())
 order=protocol['background_order'];foreground=[protocol['target'],protocol['neighbor']]
 assert len(order)==13 and len(set(order+foreground))==15 and set(records)==set(oracle)==set(payloads)==set(order+foreground)
 endpoint=os.environ['GEMMA_PROBE_ENDPOINT'].rstrip('/');headers={'Content-Type':'application/json'}
 if os.environ.get('GEMMA_PROBE_AUTH_TOKEN'):headers['Authorization']='Bearer '+os.environ['GEMMA_PROBE_AUTH_TOKEN']
 def call(route,body):return urllib.request.urlopen(urllib.request.Request(endpoint+route,data=json.dumps(body).encode(),headers=headers),timeout=3600)
 def json_call(route,body):
  with call(route,body) as response:return json.loads(response.read())
 tokens={};warmups=[]
 for rid in order+foreground:
  row=records[rid];assert digest(row['body'])==row['body_sha256']
  tokenized=json_call('/tokenize',payloads[rid]);ids=tokenized['tokens']
  assert valid_ids(ids) and len(ids)==row['original_prompt_tokens']==oracle[rid]['count']
  assert hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()==oracle[rid]['token_ids_sha256']
  tokens[rid]=ids;persist('tokenization.json',tokens)
  cached=row['original_cached_tokens']
  if cached:
   body=dict(model=row['body']['model'],prompt=ids[:cached+1],max_tokens=1,temperature=0,seed=9472,cache_salt='busy-r6-'+rid,return_token_ids=True)
   started=time.time();response=json_call('/v1/completions',body)
   assert response['usage']['prompt_tokens']==cached+1 and response['usage']['completion_tokens']==1
   assert response['choices'][0]['prompt_token_ids']==body['prompt']
   warmups.append(dict(source_response_id=rid,body=body,start=started,end=time.time(),response=response));persist('warmups.json',warmups)
 first={rid:threading.Event() for rid in records};finished={rid:threading.Event() for rid in records}
 def stream(rid,auxiliary,barrier=None):
  row=records[rid];body=dict(row['body'],seed=protocol['background_seeds'][rid] if auxiliary else protocol['foreground_seed'],cache_salt='busy-r6-'+rid,return_token_ids=True,include_reasoning=True,stream=True,stream_options={'include_usage':True})
  if auxiliary:body.update(protocol['background_override'])
  if barrier:
   barrier.wait(timeout=30)
   if rid==protocol['neighbor']:time.sleep(protocol['neighbor_submission_delay_s'])
  started=time.time();persist('request-'+rid+'.json',dict(body=body,sha256=digest(body),start=started,auxiliary=auxiliary))
  ids=[];chunks=[];usage=None;response_id=None;finish=[];prompt_ids=None;done=False;first_time=None
  try:
   with (root/('stream-'+rid+'.jsonl')).open('x') as journal:
    with call('/v1/chat/completions',body) as response:
     for raw in response:
      if not raw.startswith(b'data:'):continue
      value=raw[5:].strip();now=time.time()
      if value==b'[DONE]':done=True;break
      data=json.loads(value);journal.write(json.dumps(dict(time=now,data=data))+'\n');journal.flush()
      assert not data.get('error'),data
      if data.get('id'):
       assert response_id is None or response_id==data['id'];response_id=data['id']
      if data.get('prompt_token_ids') is not None:
       assert valid_ids(data['prompt_token_ids']) and data['prompt_token_ids']==tokens[rid]
       prompt_ids=data['prompt_token_ids']
      if data.get('usage') is not None:usage=data['usage']
      for choice in data.get('choices',[]):
       assert choice['index']==0
       part=choice.get('token_ids')
       if part is not None:
        assert valid_ids(part);ids.extend(part)
        if part and first_time is None:first_time=now;first[rid].set()
       if choice.get('finish_reason'):finish.append(choice['finish_reason'])
       if choice.get('delta'):chunks.append(choice['delta'])
   assert done and response_id and prompt_ids==tokens[rid] and usage and finish and ids
   assert usage['prompt_tokens']==row['original_prompt_tokens'] and usage['completion_tokens']==len(ids)<=8192
   cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens')
   if cached is not None:assert type(cached)is int
   # OpenAI tool parsing can relabel native length as tool_calls. Native
   # phase finish_reason must separately remain length in the final audit.
   if auxiliary:assert len(ids)==8192 and len(finish)==1 and finish[0] in ('length','tool_calls')
   else:assert len(finish)==1 and finish[0] in ('stop','length','tool_calls')
   result=dict(source_response_id=rid,response_id=response_id,auxiliary=auxiliary,body_sha256=digest(body),start=started,first_token=first_time,end=time.time(),token_ids=ids,prompt_token_ids=prompt_ids,usage=usage,finish_reasons=finish,deltas=chunks)
   persist('response-'+rid+'.json',result);return result
  except BaseException:
   persist('error-'+rid+'.json',dict(start=started,end=time.time(),response_id=response_id,token_count=len(ids),exception=traceback.format_exc()));raise
  finally:finished[rid].set()
 pool=concurrent.futures.ThreadPoolExecutor(max_workers=15);futures={}
 try:
  for rid in order:
   futures[rid]=pool.submit(stream,rid,True)
   deadline=time.monotonic()+protocol['limits']['per_background_first_token_s']
   while not first[rid].wait(.1):
    if futures[rid].done():futures[rid].result();raise RuntimeError('Condition not achieved: background completed without generated token metadata')
    if time.monotonic()>deadline:raise RuntimeError('Condition not achieved: background first-token deadline')
  snapshot=dict(time=time.time(),first={k:first[k].is_set() for k in order},finished={k:finished[k].is_set() for k in order})
  persist('foreground-release-barrier.json',snapshot)
  assert all(snapshot['first'].values()) and not any(snapshot['finished'].values()),'Condition not achieved: thirteen live backgrounds required'
  barrier=threading.Barrier(2)
  for rid in foreground:futures[rid]=pool.submit(stream,rid,False,barrier)
  results=[futures[rid].result() for rid in order+foreground]
  persist('results.json',dict(scope=protocol['scope'],rows=results))
  persist('client-complete.json',dict(requests=15,warmups=len(warmups),auxiliary_requests=13,foreground_requests=2,protocol_sha256=hashlib.sha256((root/'quality-busy-protocol-r6.json').read_bytes()).hexdigest(),client_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),status='execution complete only; actual cache/entry/slots/device-sampling and output review pending'))
 except BaseException:
  persist('client-failure.json',dict(time=time.time(),exception=traceback.format_exc(),scope='Single attempt retained; no replacement traffic or schedule-success retry'))
  # Preserve evidence and let the owning harness clean up its server. Executor
  # atexit must not hide failure behind remaining long auxiliary generations.
  os._exit(1)
 finally:pool.shutdown(wait=True)
if __name__=='__main__':main()
